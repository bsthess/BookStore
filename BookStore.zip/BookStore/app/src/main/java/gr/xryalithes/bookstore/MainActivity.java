package gr.xryalithes.bookstore;


import android.annotation.SuppressLint;
import android.content.ContentValues;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.TextView;

import gr.xryalithes.bookstore.data.BookContract;
import gr.xryalithes.bookstore.data.BookContract.BookData;
import gr.xryalithes.bookstore.data.BookDbHelper;


/**
 * Displays list of books that were entered and stored in the app.
 */
public class MainActivity extends AppCompatActivity {

    public TextView displayData;
    public TextView displayHeader;
    public TextView displayColumns;
    /**
     * Database helper that will provide us access to the database
     */
    private BookDbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayHeader = findViewById(R.id.header_text_view);
        displayData = findViewById(R.id.data_text_view);
        displayColumns = findViewById(R.id.columns_text_view);
        mDbHelper = new BookDbHelper(this);

        insertBook();
        displayBookData();
    }


    private void insertBook() {
        //
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        // Create a ContentValues object where column names are the keys,
        // and Toto's pet attributes are the values.
        ContentValues values = new ContentValues();
        values.put(BookData.COLUMN_BOOK_NAME, "Book1");
        values.put(BookData.COLUMN_BOOK_PRICE, 15);
        values.put(BookData.COLUMN_BOOK_QUANTITY, 1);
        values.put(BookData.COLUMN_SUPPLIER_NAME, "Supplier ");
        values.put(BookData.COLUMN_SUPPLIER_PHONE, 0);


        db.insert(BookData.TABLE_NAME, null, values);
    }


    private Cursor queryBookData() {
        //
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String[] projection = {
                BookData._ID,
                BookContract.BookData.COLUMN_BOOK_NAME,
                BookData.COLUMN_BOOK_PRICE,
                BookData.COLUMN_BOOK_QUANTITY,
                BookData.COLUMN_SUPPLIER_NAME,
                BookData.COLUMN_SUPPLIER_PHONE

        };

        // Perform a query on the books table
        Cursor cursor = db.query(
                BookData.TABLE_NAME,   // The table to query
                projection,            // The columns to return
                null,                  // The columns for the WHERE clause
                null,                  // The values for the WHERE clause
                null,                  // Don't group the rows
                null,                  // Don't filter by row groups
                null);                   // The sort order
        return cursor;
    }


    @SuppressLint("SetTextI18n")
    public void displayBookData() {
        Cursor cursor = queryBookData();

        try {

            displayHeader.setText("BOOKS IN STORE: " + cursor.getCount());
            displayColumns.append(
                    BookData.COLUMN_BOOK_NAME + " - " +
                    BookData.COLUMN_BOOK_PRICE + " - " +
                    BookData.COLUMN_BOOK_QUANTITY + " - " +
                    BookData.COLUMN_SUPPLIER_NAME + " - " +
                    BookData.COLUMN_SUPPLIER_PHONE + " - ");

            // Figure out the index of each column
            int idColumnIndex = cursor.getColumnIndex(BookData._ID);
            int nameColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_NAME);
            int priceColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_QUANTITY);
            int supplierNameColumnIndex = cursor.getColumnIndex(BookData.COLUMN_SUPPLIER_NAME);
            int supplierPhoneColumnIndex = cursor.getColumnIndex(BookData.COLUMN_SUPPLIER_PHONE);


            // Iterate through all the returned rows in the cursor
            while (cursor.moveToNext()) {
                // Use that index to extract the String or Int value of the word
                // at the current row the cursor is on.
                // int currentID = cursor.getInt(idColumnIndex);
                String currentName = cursor.getString(nameColumnIndex);
                int currentPrice = cursor.getInt(priceColumnIndex);
                int currentQuantity = cursor.getInt(quantityColumnIndex);
                String currentSupplierName = cursor.getString(supplierNameColumnIndex);
                int currentSupplierPhone = cursor.getInt(supplierPhoneColumnIndex);

                //todo = set the text in displayData TextView with the above strings and integers so we can view our data.
                displayData.append(currentName  + " "
                        + currentPrice + " "
                        + currentQuantity + " "
                        + currentSupplierName + " "
                        + currentSupplierPhone + "\n");
            }
        } finally {
            // Always close the cursor when you're done reading from it. This releases all its
            // resources and makes it invalid.
            cursor.close();
        }
    }


}