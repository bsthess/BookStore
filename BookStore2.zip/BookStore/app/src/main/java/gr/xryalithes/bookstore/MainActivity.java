package gr.xryalithes.bookstore;


import android.annotation.SuppressLint;
import android.content.ContentValues;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.TextView;

import gr.xryalithes.bookstore.data.BookContract;
import gr.xryalithes.bookstore.data.BookContract.BookData;
import gr.xryalithes.bookstore.data.BookDbHelper;


/**
 * Displays list of books that were entered and stored in the app.
 */
public class MainActivity extends AppCompatActivity {


    TextView displayHeaderView;
     TextView displayNameView;
    TextView displayPriceView;
     TextView displayQuantityView;
     TextView displaySupplierNameView;
     TextView displaySupplierPhoneView;

    /**
     * Database helper that will provide us access to the database
     */
    private BookDbHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayHeaderView = findViewById(R.id.header_text_view);
        displayNameView = findViewById(R.id.name_text_view);
        displayPriceView = findViewById(R.id.price_text_view);
        displayQuantityView = findViewById(R.id.quantity_text_view);
        displaySupplierNameView = findViewById(R.id.supplier_name_text_view);
        displaySupplierPhoneView = findViewById(R.id.supplier_phone_text_view);


        mDbHelper = new BookDbHelper(this);

        insertBook();
        displayBookData();
    }


    private void insertBook() {
        //
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        // Create a ContentValues object where column names are the keys,
        // and Toto's pet attributes are the values.
        ContentValues values = new ContentValues();
        values.put(BookData.COLUMN_BOOK_NAME, "Book1");
        values.put(BookData.COLUMN_BOOK_PRICE, 15);
        values.put(BookData.COLUMN_BOOK_QUANTITY, 1);
        values.put(BookData.COLUMN_SUPPLIER_NAME, "Supplier ");
        values.put(BookData.COLUMN_SUPPLIER_PHONE, 0);


        db.insert(BookData.TABLE_NAME, null, values);
    }


    private Cursor queryBookData() {
        //
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String[] projection = {
                BookData._ID,
                BookContract.BookData.COLUMN_BOOK_NAME,
                BookData.COLUMN_BOOK_PRICE,
                BookData.COLUMN_BOOK_QUANTITY,
                BookData.COLUMN_SUPPLIER_NAME,
                BookData.COLUMN_SUPPLIER_PHONE

        };

        // Perform a query on the books table
        Cursor cursor = db.query(
                BookData.TABLE_NAME,   // The table to query
                projection,            // The columns to return
                null,                  // The columns for the WHERE clause
                null,                  // The values for the WHERE clause
                null,                  // Don't group the rows
                null,                  // Don't filter by row groups
                null);                   // The sort order
        return cursor;
    }


    @SuppressLint("SetTextI18n")
    public void displayBookData() {
        Cursor cursor = queryBookData();

        try {

            displayHeaderView.setText("BOOKS IN STORE: " + cursor.getCount());
            displayNameView.setText(BookData.COLUMN_BOOK_NAME + "\n");
            displayPriceView.setText(BookData.COLUMN_BOOK_PRICE + "\n");
            displayQuantityView.setText(BookData.COLUMN_BOOK_QUANTITY +"\n");
            displaySupplierNameView.setText(BookData.COLUMN_SUPPLIER_NAME + "\n");
            displaySupplierPhoneView.setText(BookData.COLUMN_SUPPLIER_PHONE +"\n");




            // Figure out the index of each column

            int nameColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_NAME);
            int priceColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(BookData.COLUMN_BOOK_QUANTITY);
            int supplierNameColumnIndex = cursor.getColumnIndex(BookData.COLUMN_SUPPLIER_NAME);
            int supplierPhoneColumnIndex = cursor.getColumnIndex(BookData.COLUMN_SUPPLIER_PHONE);


            // Iterate through all the returned rows in the cursor
            while (cursor.moveToNext()) {
                // Use that index to extract the String or Int value of the word
                // at the current row the cursor is on.
                // int currentID = cursor.getInt(idColumnIndex);
                String currentName = cursor.getString(nameColumnIndex);
                int currentPrice = cursor.getInt(priceColumnIndex);
                int currentQuantity = cursor.getInt(quantityColumnIndex);
                String currentSupplierName = cursor.getString(supplierNameColumnIndex);
                long currentSupplierPhone = cursor.getLong(supplierPhoneColumnIndex);

                displayNameView.append(currentName + " \n");
                displayPriceView.append(currentPrice + " \n");
                displayQuantityView.append(currentQuantity + " \n");
                displaySupplierNameView.append(currentSupplierName + " \n");
                displaySupplierPhoneView.append(currentSupplierPhone + " \n");


            }
        } finally {
            // Always close the cursor when you're done reading from it. This releases all its
            // resources and makes it invalid.
            cursor.close();
        }
    }


}