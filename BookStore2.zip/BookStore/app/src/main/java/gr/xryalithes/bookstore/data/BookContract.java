package gr.xryalithes.bookstore.data;

import android.provider.BaseColumns;



public final class BookContract {

    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    private BookContract() {
    }


    /**
     * Inner class that defines constant values for the pets database table.
     * Each entry in the table represents a single book.
     */
    public static final class BookData implements BaseColumns {

        /**
         * Name of database table for pets
         */
        public final static String TABLE_NAME = "books";

        /**
         * Unique ID number for the book (only for use in the database table).
         * <p>
         * Type: INTEGER
         */
        public final static String _ID = BaseColumns._ID;

        /**
         * Name of the book.
         * <p>
         * Type: TEXT
         */
        public final static String COLUMN_BOOK_NAME = "title";

        /**
         * Price of the book.
         * <p>
         * Type: INTEGER  Can't be NULL
         */
        public final static String COLUMN_BOOK_PRICE = "price";


        /**
         * Quantity of books in the store. Can be NULL
         * <p>
         * Type: INTEGER Can be NULL
         */
        public final static String COLUMN_BOOK_QUANTITY = "quantity";

        /**
         * Supplier name.
         * <p>
         * Type: TEXT , can't be NULL
         */
        public final static String COLUMN_SUPPLIER_NAME = "supplier";
        /**
         * Supplier phone number
         * Type: Integer , can be NULL
         */

        public final static String COLUMN_SUPPLIER_PHONE = "supplier_phone";

    }

}
